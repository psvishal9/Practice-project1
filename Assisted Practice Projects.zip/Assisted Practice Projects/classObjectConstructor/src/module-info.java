/**
 * 
 */
/**
 * 
 */
module classObjectConstructor {
}