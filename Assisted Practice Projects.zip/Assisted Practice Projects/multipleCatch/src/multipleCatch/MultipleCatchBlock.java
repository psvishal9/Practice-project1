package io.com;
public class MultipleCatchBlock {
public static void main(String[] args) {
try{
int a[]=new int[5];
System.out.println(a[10]);
}
catch(ArithmeticException e){
System.out.println("Arithmetic exception");
}
catch(ArrayIndexOutOfBoundsException e){
}
System.out.println("ArrayIndexOutOfBounds exception");
catch(Exception e){
System.out.println("Parent exception");
}
System.out.println("rest of the code");
}
}
class Excep1{
public static void main(String args[]){
try{
try{
System.out.println("going to divide");
intb =39/0;
}catch(ArithmeticException e){ System.out.println(e);}
try{
int a[]=newint[5];
a[5]=4;
}
catch(ArrayIndexOutOfBoundsException e)
{
System.out.println(e);
}
System.out.println("another statement");
}
catch(Exception e)
{
System.out.println("handeled");
}
System.out.println("normal flow..");
}
}